# Roadmap

## OpenBCI WiFi NodeJS

Make programming with OpenBCI reliable, easy, research grade and fun!

## Short term - what we're working on now

- Add examples of data extraction
- Documentation

## Medium term

- Emotion detection
