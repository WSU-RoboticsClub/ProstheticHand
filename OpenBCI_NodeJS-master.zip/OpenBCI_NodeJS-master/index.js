module.exports.Cyton = require('openbci-cyton');
module.exports.Ganglion = require('openbci-ganglion');
module.exports.Wifi = require('openbci-wifi');
