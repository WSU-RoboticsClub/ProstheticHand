 
* default set of instructions to send to the board on startup via command line
* make a proper package
* requirements.txt for pip
* fix long recording crash (might be hardware or software fix)

